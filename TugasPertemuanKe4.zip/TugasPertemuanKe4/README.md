# Tutorial-Farizdotid
Project ini berisi source code sederhana yang berasal dari tutorial web farizdotid ( https://farizdotid.com/ ) .

### Contoh sederhana yang ada di repo ini 

* Radio Button Example 
* Date Picker Example 
* Email Validation Example 
* Image Circle Example
* Date Range Picker Example
* Adapter Click With Listener Example
* Tab Layout Google Play Example
* Glide Loading Example
* Custom Font Example
* Corder Radius Glide Example
* Open Whatsapp Example

### Note
Semua tutorial pemrograman android sederhana yang ada di web saya akan saya update di repo ini.